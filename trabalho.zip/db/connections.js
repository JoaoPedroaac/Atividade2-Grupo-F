const writeCfg = {
  host: "localhost",
  port: 3307,
  user: "rootuser",
  password: "grupof.pass",
  database: "aula-db",
};

const readCfg = {
  host: "localhost",
  port: 3308,
  user: "replicuser",
  password: "grupof.pass",
  database: "aula-db",
};

module.exports = { writeCfg, readCfg };
