const mysql = require("mysql2/promise");
const { writeCfg, readCfg } = require("./connections");

function sleep(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

async function createPools() {
  while (true) {
    try {
      const writePool = await mysql.createPool(writeCfg);
      const readPool = await mysql.createPool(readCfg);
      return { writePool, readPool };
    } catch (err) {
      console.log("⏳ Aguardando bancos subirem...");
      await sleep(3000);
    }
  }
}

module.exports = { createPools };
